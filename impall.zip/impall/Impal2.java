/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package impal2;

import java.util.Scanner;

/**
 *
 * @author WIN 10
 */
public class Impal2 {

    /**
     * @param args the command line arguments
     * 
     * 
     */
     
    public static void main(String[] args) {
        // TODO code application logic here
        int banyak_komputer;
        int total_pembayaran;
        String hari_servis;
        int base_fee = 50;
        int aditional_fee = 10;
        String drop_off;
        Scanner scan = new Scanner(System.in);
        System.out.println("Banyak Komputer di service :");
        banyak_komputer = scan.nextInt();
        System.out.println("Hari Servis hari kerja? [y/n]");
        hari_servis = scan.next();
        System.out.println("Drop off dan pick up barang? [y/n]");
        drop_off = scan.next();
        
        if (banyak_komputer <=2 && hari_servis.equals("n") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer <= 10 && banyak_komputer >=3 && hari_servis.equals("n") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee*2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer >10 && hari_servis.equals("n") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee*10  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if (banyak_komputer <=2 && hari_servis.equals("y") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee*2  +"$"+ " & additional fee = "+ aditional_fee*0);
        }else if(banyak_komputer <= 10 && banyak_komputer >=3 && hari_servis.equals("y") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee*2*2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer >10 && hari_servis.equals("y") && drop_off.equals("n")){
            System.out.println("base fee = "+ base_fee*10*2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
            
        }else if (banyak_komputer <=2 && hari_servis.equals("n") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee/2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer <= 10 && banyak_komputer >=3 && hari_servis.equals("n") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee*2/2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer >10 && hari_servis.equals("n") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee*10/2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if (banyak_komputer <=2 && hari_servis.equals("y") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee*2/2  +"$"+ " & additional fee = "+ aditional_fee*0);
        }else if(banyak_komputer <= 10 && banyak_komputer >=3 && hari_servis.equals("y") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee*2*2/2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else if(banyak_komputer >10 && hari_servis.equals("y") && drop_off.equals("y")){
            System.out.println("base fee = "+ base_fee*10*2/2  +"$"+ " & additional fee = "+ aditional_fee*banyak_komputer+"$");
        }else{
            System.out.println("Isi dengan benar");
    }
        
        
        
    }
        
    }
    

